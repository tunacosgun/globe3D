//
//  GlobeDraftApp.swift
//  GlobeDraft
//
//  Created by Elif Parlak on 4.08.2025.
//

import SwiftUI

@main
struct GlobeDraftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

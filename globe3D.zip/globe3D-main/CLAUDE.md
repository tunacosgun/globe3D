# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

GlobeDraft is an iOS SwiftUI application that displays an interactive 3D Earth globe for flight visualization. The app features:
- 3D rotating Earth using SceneKit with real NASA texture mapping
- City search functionality with auto-complete
- Interactive zoom-to-city with smooth camera transitions
- City markers with pulsing animations
- Flight path visualization capabilities (planned)
- Coordinate system conversion from lat/long to 3D sphere positions

## Build and Development Commands

### Building the App
```bash
# Build from command line (requires Xcode Command Line Tools)
xcodebuild -project GlobeDraft.xcodeproj -scheme GlobeDraft -destination 'platform=iOS Simulator,name=iPhone 15' build

# Clean build
xcodebuild -project GlobeDraft.xcodeproj -scheme GlobeDraft clean
```

### Running the App
- Use Xcode IDE: Open `GlobeDraft.xcodeproj` and run with Cmd+R
- The app targets iOS 18.0+ and supports both iPhone and iPad
- Test city search functionality with sample cities: Istanbul, London, New York, Tokyo, Paris, Sydney, Dubai, Los Angeles, Moscow, Cairo

## Project Structure

```
GlobeDraft/
├── ContentView.swift                   // Main app container
├── GlobeDraftApp.swift                 // App entry point
├── CLAUDE.md                          // AI development guidance
├── Assets.xcassets/
│   └── earth_texture.imageset/        // Earth texture assets
└── Screens/
    └── Home/                          // Home screen (main globe view)
        ├── Views/
        │   ├── HomeView.swift         // Main home container
        │   ├── EarthSceneView.swift   // SceneKit 3D rendering
        │   └── SearchOverlayView.swift // Search interface overlay
        ├── ViewModels/
        │   └── HomeViewModel.swift    // Home screen state management
        └── Models/
            └── City.swift             // City data model with coordinates
```

## Architecture

### Core Components

**GlobeDraftApp.swift**: Main app entry point using SwiftUI App lifecycle

**ContentView.swift**: Simple container that displays HomeView

**Home Screen Components**:
- `HomeView`: Main container orchestrating 3D globe and search overlay
- `EarthSceneView`: UIViewRepresentable bridging SwiftUI to SceneKit
- `SearchOverlayView`: Search interface with city filtering and selection
- `HomeViewModel`: State management for selected city and search functionality

**Models**:
- `City`: Data model with name, country, coordinates, and 3D position conversion
- `sampleCities`: Hardcoded database of major world cities for testing

### 3D Rendering Details

The Earth visualization uses SceneKit with:
- `SCNSphere` geometry (radius: 0.7) for Earth base
- NASA Blue Marble texture mapping (earth_texture.jpg)
- Dual lighting setup: ambient (intensity: 800) + directional (intensity: 600)
- Continuous Y-axis rotation (20-second cycle) that pauses during city focus
- Interactive camera controls with programmatic zoom animations

### City Search & Visualization Features

**Search System**:
- Real-time filtering by city name or country
- Maximum 8 results displayed at once
- Case-insensitive search with localized support

**City Markers**:
- Red glowing spheres (radius: 0.02) positioned above surface
- Pulsing scale animation (1.0 to 1.5x scale)
- Emission material for glow effect
- Automatic cleanup of previous markers

**Camera Animation**:
- Smooth 2-second transition to selected city
- Camera distance: 1.5 units from city position
- EaseInEaseOut timing for natural movement
- Automatic look-at targeting for city focus

### Coordinate System

**Conversion Formula** (lat/long to SCNVector3):
```swift
let x = radius * cos(latRad) * cos(lonRad)
let y = radius * sin(latRad)  
let z = radius * cos(latRad) * sin(lonRad)
```

**Coordinate Mapping**:
- World coordinates: Latitude (-90° to +90°), Longitude (-180° to +180°)
- SceneKit space: Y-axis (poles), X/Z-axis (equatorial plane)
- Surface offset: +0.03 units above sphere surface for markers

## Asset Dependencies

**Required Assets**:
- **earth_texture.jpg**: NASA Blue Marble texture (recommended: 2048x1024 resolution)
  - Source: https://visibleearth.nasa.gov/images/57752/blue-marble-land-surface-shallow-water-and-shaded-topography
  - Must be added to Xcode bundle as "earth_texture"
  
**Fallback System**:
- Procedural texture generation with basic continent shapes if NASA texture is missing
- Console warning: "⚠️ earth_texture.jpg bulunamadı - basit texture kullanılıyor"

## Development Notes

### Technical Requirements
- Project uses Xcode 16.0 with Swift 5.0
- Deployment target: iOS 18.0
- Required frameworks: SwiftUI, SceneKit, CoreLocation
- Bundle identifier: elifbilgeparlak.GlobeDraft
- Development team: Y5JW4F4D62

### Performance Considerations
- Earth rotation pauses during city selection to reduce GPU load
- City markers limited to one active marker at a time
- Lighting optimized for balance between realism and performance
- Texture size should not exceed 4K to prevent memory issues

### Future Development (Planned Features)
- Flight path visualization with great circle calculations
- Multiple city selection (departure/arrival)
- Bezier curve flight routes
- Level of detail (LOD) system for performance optimization
- Real-time flight data integration

## Code Style Guidelines

**File Organization**:
- Screens/ directory contains individual app screens (Home, Product, Detail, etc.)
- Each screen has Views/, ViewModels/, and Models/ subdirectories
- Main view files orchestrate atomic components
- Atomic components are defined in the same file or separate files as needed

**SwiftUI View Structure**:
- **ATOMIC DESIGN**: Break complex views into small, focused components
- **NO MASSIVE BODY**: Main view body should orchestrate components, not contain all UI logic
- **COMPOSITION OVER COMPLEXITY**: Prefer multiple small views over one large view

**Example Structure Pattern**:
```swift
// ❌ DON'T: Everything in body
struct ComplexView: View {
    var body: some View {
        VStack {
            // 100+ lines of UI code...
        }
    }
}

// ✅ DO: Atomic components
struct MainView: View {
    var body: some View {
        VStack {
            HeaderComponent()
            ContentArea()
            FooterActions()
        }
    }
}

struct HeaderComponent: View { /* focused component */ }
struct ContentArea: View { /* focused component */ }
struct FooterActions: View { /* focused component */ }
```

**Naming Conventions**:
- Views: `[Feature][Purpose]View.swift` (e.g., `SearchBarView.swift`)
- ViewModels: `[Feature]ViewModel.swift` (e.g., `GlobeViewModel.swift`)
- Components: `[ComponentName].swift` (e.g., `CityMarker.swift`)
- Models: `[EntityName].swift` (e.g., `City.swift`)

**Component Guidelines**:
- Each component should have a single responsibility
- Prefer @ViewBuilder computed properties for complex sub-layouts
- Extract reusable animations into Shared/Utils/AnimationHelper.swift
- Use extensions for view modifiers (Shared/Extensions/)

## Code Style Notes

- Mixed Turkish and English comments reflecting development team language
- SwiftUI + UIViewRepresentable pattern for SceneKit integration
- Reactive programming with @State and @Binding for UI updates
- Modular architecture separating UI, 3D rendering, and data models
- Defensive programming with fallback systems for missing assets

## Testing Checklist

### Core Functionality
- [ ] Earth loads with NASA texture (or fallback if missing)
- [ ] Continuous rotation animation works
- [ ] Search interface opens/closes correctly
- [ ] City filtering works with partial text input
- [ ] City selection triggers zoom animation
- [ ] Red marker appears at correct city location
- [ ] Camera smoothly transitions to city view
- [ ] Multiple city selections work without memory leaks

### Performance Tests
- [ ] Smooth 60fps rotation on target devices
- [ ] No memory leaks during repeated city selections
- [ ] Search performance remains responsive with all cities
- [ ] Camera animations don't cause frame drops

### Edge Cases
- [ ] Empty search query handling
- [ ] Special characters in city names
- [ ] Very long city/country names in UI
- [ ] Rapid city selection changes
- [ ] Device rotation support